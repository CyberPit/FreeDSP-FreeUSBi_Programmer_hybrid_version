(kicad_sch
	(version 20250114)
	(generator "eeschema")
	(generator_version "9.0")
	(uuid "f506b08e-6af4-4eb1-89c4-06960ac40582")
	(paper "A4")
	(title_block
		(title "freeUSBi V0.5")
		(date "2025-05-03")
		(rev "0.5")
		(company "www.freedsp.cc")
		(comment 1 "www.creativecommons.org/licenses/by-sa/4.0/legalcode")
	)
	(lib_symbols
		(symbol "Connector_Generic:Conn_02x05_Odd_Even"
			(pin_names
				(offset 1.016)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "J"
				(at 1.27 7.62 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "Conn_02x05_Odd_Even"
				(at 1.27 -7.62 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" "~"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Generic connector, double row, 02x05, odd/even pin numbering scheme (row 1 odd numbers, row 2 even numbers), script generated (kicad-library-utils/schlib/autogen/connector/)"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "connector"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "Connector*:*_2x??_*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "Conn_02x05_Odd_Even_1_1"
				(rectangle
					(start -1.27 6.35)
					(end 3.81 -6.35)
					(stroke
						(width 0.254)
						(type default)
					)
					(fill
						(type background)
					)
				)
				(rectangle
					(start -1.27 5.207)
					(end 0 4.953)
					(stroke
						(width 0.1524)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 2.667)
					(end 0 2.413)
					(stroke
						(width 0.1524)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 0.127)
					(end 0 -0.127)
					(stroke
						(width 0.1524)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 -2.413)
					(end 0 -2.667)
					(stroke
						(width 0.1524)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 -4.953)
					(end 0 -5.207)
					(stroke
						(width 0.1524)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 5.207)
					(end 2.54 4.953)
					(stroke
						(width 0.1524)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 2.667)
					(end 2.54 2.413)
					(stroke
						(width 0.1524)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 0.127)
					(end 2.54 -0.127)
					(stroke
						(width 0.1524)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 -2.413)
					(end 2.54 -2.667)
					(stroke
						(width 0.1524)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 -4.953)
					(end 2.54 -5.207)
					(stroke
						(width 0.1524)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(pin passive line
					(at -5.08 5.08 0)
					(length 3.81)
					(name "Pin_1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 2.54 0)
					(length 3.81)
					(name "Pin_3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 0 0)
					(length 3.81)
					(name "Pin_5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 -2.54 0)
					(length 3.81)
					(name "Pin_7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 -5.08 0)
					(length 3.81)
					(name "Pin_9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 5.08 180)
					(length 3.81)
					(name "Pin_2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 2.54 180)
					(length 3.81)
					(name "Pin_4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 0 180)
					(length 3.81)
					(name "Pin_6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 -2.54 180)
					(length 3.81)
					(name "Pin_8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 -5.08 180)
					(length 3.81)
					(name "Pin_10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "Device:CP"
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0.254)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "C"
				(at 0.635 2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Value" "Device_CP"
				(at 0.635 -2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Footprint" ""
				(at 0.9652 -3.81 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "CP_*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "CP_0_1"
				(rectangle
					(start -2.286 0.508)
					(end 2.286 1.016)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.778 2.286) (xy -0.762 2.286)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 2.794) (xy -1.27 1.778)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 2.286 -0.508)
					(end -2.286 -1.016)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
			)
			(symbol "CP_1_1"
				(pin passive line
					(at 0 3.81 270)
					(length 2.794)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 0 -3.81 90)
					(length 2.794)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "Device:LED"
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 1.016)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "D"
				(at 0 2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "LED"
				(at 0 -2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" "~"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Light emitting diode"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Sim.Pins" "1=K 2=A"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "LED diode"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "LED* LED_SMD:* LED_THT:*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "LED_0_1"
				(polyline
					(pts
						(xy -3.048 -0.762) (xy -4.572 -2.286) (xy -3.81 -2.286) (xy -4.572 -2.286) (xy -4.572 -1.524)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.778 -0.762) (xy -3.302 -2.286) (xy -2.54 -2.286) (xy -3.302 -2.286) (xy -3.302 -1.524)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 0) (xy 1.27 0)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 -1.27) (xy -1.27 1.27)
					)
					(stroke
						(width 0.254)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 -1.27) (xy 1.27 1.27) (xy -1.27 0) (xy 1.27 -1.27)
					)
					(stroke
						(width 0.254)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "LED_1_1"
				(pin passive line
					(at -3.81 0 0)
					(length 2.54)
					(name "K"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 3.81 0 180)
					(length 2.54)
					(name "A"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "Device:Q_NMOS_SGD"
			(pin_names
				(offset 0)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "Q"
				(at 5.08 1.27 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Value" "Device_Q_NMOS_SGD"
				(at 5.08 -1.27 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Footprint" ""
				(at 5.08 2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "Q_NMOS_SGD_0_1"
				(polyline
					(pts
						(xy 0.254 1.905) (xy 0.254 -1.905)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.254 0) (xy -2.54 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.762 2.286) (xy 0.762 1.27)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.762 0.508) (xy 0.762 -0.508)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.762 -1.27) (xy 0.762 -2.286)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.762 -1.778) (xy 3.302 -1.778) (xy 3.302 1.778) (xy 0.762 1.778)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.016 0) (xy 2.032 0.381) (xy 2.032 -0.381) (xy 1.016 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center 1.651 0)
					(radius 2.794)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.54 2.54) (xy 2.54 1.778)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 2.54 1.778)
					(radius 0.254)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center 2.54 -1.778)
					(radius 0.254)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy 2.54 -2.54) (xy 2.54 0) (xy 0.762 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.794 0.508) (xy 2.921 0.381) (xy 3.683 0.381) (xy 3.81 0.254)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 0.381) (xy 2.921 -0.254) (xy 3.683 -0.254) (xy 3.302 0.381)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "Q_NMOS_SGD_1_1"
				(pin input line
					(at -5.08 0 0)
					(length 5.08)
					(name "G"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 5.08 270)
					(length 2.54)
					(name "D"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 -5.08 90)
					(length 2.54)
					(name "S"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "Device:R"
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "R"
				(at 2.032 0 90)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "R"
				(at 0 0 90)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at -1.778 0 90)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" "~"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Resistor"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "R res resistor"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "R_*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "R_0_1"
				(rectangle
					(start -1.016 -2.54)
					(end 1.016 2.54)
					(stroke
						(width 0.254)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "R_1_1"
				(pin passive line
					(at 0 3.81 270)
					(length 1.27)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 0 -3.81 90)
					(length 1.27)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "USBi_Programmer-rescue:2N7002-dk_Transistors-FETs-MOSFETs-Single"
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "Q"
				(at -2.6924 3.6322 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify right)
				)
			)
			(property "Value" "2N7002-dk_Transistors-FETs-MOSFETs-Single"
				(at 3.4544 0 90)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" "digikey-footprints:SOT-23-3"
				(at 5.08 5.08 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify left)
					(hide yes)
				)
			)
			(property "Datasheet" "https://www.onsemi.com/pub/Collateral/NDS7002A-D.PDF"
				(at 5.08 7.62 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify left)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Digi-Key_PN" "2N7002NCT-ND"
				(at 5.08 10.16 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify left)
					(hide yes)
				)
			)
			(property "MPN" "2N7002"
				(at 5.08 12.7 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify left)
					(hide yes)
				)
			)
			(property "Category" "Discrete Semiconductor Products"
				(at 5.08 15.24 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify left)
					(hide yes)
				)
			)
			(property "Family" "Transistors - FETs, MOSFETs - Single"
				(at 5.08 17.78 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify left)
					(hide yes)
				)
			)
			(property "DK_Datasheet_Link" "https://www.onsemi.com/pub/Collateral/NDS7002A-D.PDF"
				(at 5.08 20.32 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify left)
					(hide yes)
				)
			)
			(property "DK_Detail_Page" "/product-detail/en/on-semiconductor/2N7002/2N7002NCT-ND/244664"
				(at 5.08 22.86 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify left)
					(hide yes)
				)
			)
			(property "Description_1" "MOSFET N-CH 60V 115MA SOT-23"
				(at 5.08 25.4 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify left)
					(hide yes)
				)
			)
			(property "Manufacturer" "ON Semiconductor"
				(at 5.08 27.94 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify left)
					(hide yes)
				)
			)
			(property "Status" "Active"
				(at 5.08 30.48 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(justify left)
					(hide yes)
				)
			)
			(symbol "2N7002-dk_Transistors-FETs-MOSFETs-Single_0_1"
				(polyline
					(pts
						(xy -5.08 -2.54) (xy -3.048 -2.54) (xy -3.048 1.397)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center -1.27 0)
					(radius 3.302)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
				(polyline
					(pts
						(xy -0.127 -1.905) (xy 1.016 -1.905) (xy 1.016 1.397) (xy 1.016 1.905) (xy -0.127 1.905)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 2.54) (xy 0 1.397) (xy -2.54 1.397)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 0 1.905)
					(radius 0.127)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 -1.397) (xy -2.54 -1.397)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 0 -1.397)
					(radius 0.127)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 0 -1.905)
					(radius 0.127)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 -2.54) (xy 0 0) (xy -2.54 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "2N7002-dk_Transistors-FETs-MOSFETs-Single_1_1"
				(polyline
					(pts
						(xy -2.54 1.905) (xy -2.54 0.889)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.54 0) (xy -2.54 0.508)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.54 0) (xy -2.54 -0.508)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.54 0) (xy -1.778 0.508) (xy -1.778 -0.508) (xy -2.54 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy -2.54 -1.397) (xy -2.54 -0.889)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.54 -1.397) (xy -2.54 -1.905)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.016 0.508) (xy 0.508 -0.254) (xy 1.524 -0.254) (xy 1.016 0.508)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy 1.524 0.508) (xy 0.508 0.508)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(pin bidirectional line
					(at -7.62 -2.54 0)
					(length 2.54)
					(name "G"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 0 5.08 270)
					(length 2.54)
					(name "D"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 0 -5.08 90)
					(length 2.54)
					(name "S"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "USBi_Programmer-rescue:Conn_01x02-conn"
			(pin_names
				(offset 1.016)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "J"
				(at 0 2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "Conn_01x02-conn"
				(at 0 -5.08 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "Connector*:*_??x*mm* Connector*:*1x??x*mm* Pin?Header?Straight?1X* Pin?Header?Angled?1X* Socket?Strip?Straight?1X* Socket?Strip?Angled?1X*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "Conn_01x02-conn_1_1"
				(rectangle
					(start -1.27 1.27)
					(end 1.27 -3.81)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type background)
					)
				)
				(rectangle
					(start -1.27 0.127)
					(end 0 -0.127)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 -2.413)
					(end 0 -2.667)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(pin passive line
					(at -5.08 0 0)
					(length 3.81)
					(name "Pin_1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 -2.54 0)
					(length 3.81)
					(name "Pin_2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "USBi_Programmer-rescue:Conn_02x10_Odd_Even-conn"
			(pin_names
				(offset 1.016)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "J"
				(at 1.27 12.7 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "Conn_02x10_Odd_Even-conn"
				(at 1.27 -15.24 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "Connector*:*2x??x*mm* Connector*:*2x???Pitch* Pin_Header_Straight_2X* Pin_Header_Angled_2X* Socket_Strip_Straight_2X* Socket_Strip_Angled_2X*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "Conn_02x10_Odd_Even-conn_1_1"
				(rectangle
					(start -1.27 11.43)
					(end 3.81 -13.97)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type background)
					)
				)
				(rectangle
					(start -1.27 10.287)
					(end 0 10.033)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 7.747)
					(end 0 7.493)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 5.207)
					(end 0 4.953)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 2.667)
					(end 0 2.413)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 0.127)
					(end 0 -0.127)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 -2.413)
					(end 0 -2.667)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 -4.953)
					(end 0 -5.207)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 -7.493)
					(end 0 -7.747)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 -10.033)
					(end 0 -10.287)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.27 -12.573)
					(end 0 -12.827)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 10.287)
					(end 2.54 10.033)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 7.747)
					(end 2.54 7.493)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 5.207)
					(end 2.54 4.953)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 2.667)
					(end 2.54 2.413)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 0.127)
					(end 2.54 -0.127)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 -2.413)
					(end 2.54 -2.667)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 -4.953)
					(end 2.54 -5.207)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 -7.493)
					(end 2.54 -7.747)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 -10.033)
					(end 2.54 -10.287)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 3.81 -12.573)
					(end 2.54 -12.827)
					(stroke
						(width 0.1524)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(pin passive line
					(at -5.08 10.16 0)
					(length 3.81)
					(name "Pin_1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 7.62 0)
					(length 3.81)
					(name "Pin_3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 5.08 0)
					(length 3.81)
					(name "Pin_5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 2.54 0)
					(length 3.81)
					(name "Pin_7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 0 0)
					(length 3.81)
					(name "Pin_9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 -2.54 0)
					(length 3.81)
					(name "Pin_11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 -5.08 0)
					(length 3.81)
					(name "Pin_13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 -7.62 0)
					(length 3.81)
					(name "Pin_15"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "15"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 -10.16 0)
					(length 3.81)
					(name "Pin_17"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "17"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 -12.7 0)
					(length 3.81)
					(name "Pin_19"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "19"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 10.16 180)
					(length 3.81)
					(name "Pin_2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 7.62 180)
					(length 3.81)
					(name "Pin_4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 5.08 180)
					(length 3.81)
					(name "Pin_6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 2.54 180)
					(length 3.81)
					(name "Pin_8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 0 180)
					(length 3.81)
					(name "Pin_10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 -2.54 180)
					(length 3.81)
					(name "Pin_12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 -5.08 180)
					(length 3.81)
					(name "Pin_14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 -7.62 180)
					(length 3.81)
					(name "Pin_16"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "16"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 -10.16 180)
					(length 3.81)
					(name "Pin_18"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "18"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 -12.7 180)
					(length 3.81)
					(name "Pin_20"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "20"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "power:+3.3V"
			(power)
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "#PWR"
				(at 0 -3.81 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Value" "+3.3V"
				(at 0 3.556 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Power symbol creates a global label with name \"+3.3V\""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "global power"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "+3.3V_0_1"
				(polyline
					(pts
						(xy -0.762 1.27) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 2.54) (xy 0.762 1.27)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "+3.3V_1_1"
				(pin power_in line
					(at 0 0 90)
					(length 0)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "power:+5VD"
			(power)
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "#PWR"
				(at 0 -3.81 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Value" "+5VD"
				(at 0 3.556 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Power symbol creates a global label with name \"+5VD\""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "global power"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "+5VD_0_1"
				(polyline
					(pts
						(xy -0.762 1.27) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 2.54) (xy 0.762 1.27)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "+5VD_1_1"
				(pin power_in line
					(at 0 0 90)
					(length 0)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "power:GND"
			(power)
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "#PWR"
				(at 0 -6.35 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Value" "GND"
				(at 0 -3.81 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Power symbol creates a global label with name \"GND\" , ground"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "global power"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "GND_0_1"
				(polyline
					(pts
						(xy 0 0) (xy 0 -1.27) (xy 1.27 -1.27) (xy 0 -2.54) (xy -1.27 -1.27) (xy 0 -1.27)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "GND_1_1"
				(pin power_in line
					(at 0 0 270)
					(length 0)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "power:PWR_FLAG"
			(power)
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "#FLG"
				(at 0 1.905 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Value" "PWR_FLAG"
				(at 0 3.81 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" "~"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Special symbol for telling ERC where power comes from"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "flag power"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "PWR_FLAG_0_0"
				(pin power_out line
					(at 0 0 90)
					(length 0)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(symbol "PWR_FLAG_0_1"
				(polyline
					(pts
						(xy 0 0) (xy 0 1.27) (xy -1.016 1.905) (xy 0 2.54) (xy 1.016 1.905) (xy 0 1.27)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(embedded_fonts no)
		)
	)
	(text "POWER LED (RED)\n"
		(exclude_from_sim no)
		(at 60.96 159.385 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "0722c6fb-338b-4502-8fdf-b76986c219a4")
	)
	(text "IFCLK"
		(exclude_from_sim no)
		(at 111.76 62.23 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "08604bcb-2477-4196-9867-ca40a897b96c")
	)
	(text "Contents of the website and freeUSBi design files (KiCAD) are licensed under a \nCreative Commons Attribution Share-Alike 4.0 license. This allows for \nboth personal and commercial derivative works, as long as they credit\nfreeUSBi and release their designs under the same license."
		(exclude_from_sim no)
		(at 179.705 175.895 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "0c0bca71-be25-4d5a-962d-0d7bc5b82945")
	)
	(text "PA5"
		(exclude_from_sim no)
		(at 180.34 58.42 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "0ef3fbef-dcd0-4916-a3c0-8e20e3f2dbff")
	)
	(text "PB4"
		(exclude_from_sim no)
		(at 180.34 73.66 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "18399cbb-ace8-4395-a1d8-baa8b7ed619a")
	)
	(text "PD1"
		(exclude_from_sim no)
		(at 180.34 53.34 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "1ab070e0-8915-4779-9a2c-5b381f1952ef")
	)
	(text "PA7"
		(exclude_from_sim no)
		(at 180.34 55.88 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "21339638-472d-4362-8f19-c815aa7e5449")
	)
	(text "PB1"
		(exclude_from_sim no)
		(at 111.76 67.31 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "2922c217-4ac8-4daa-bcce-113f7baead59")
	)
	(text "GND"
		(exclude_from_sim no)
		(at 111.76 54.61 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "292373ff-d6ca-4017-9e0c-1bf37bd54b86")
	)
	(text "GND/VCC"
		(exclude_from_sim no)
		(at 111.76 59.69 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "3fef87c6-3455-4e70-a079-850bef3f9e48")
	)
	(text "RDY0"
		(exclude_from_sim no)
		(at 99.06 57.15 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "4008a1d5-3efd-47fd-9112-598fec298c24")
	)
	(text "PA4"
		(exclude_from_sim no)
		(at 167.64 60.96 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "45ffd223-cdbe-4452-b503-01a07c53adf9")
	)
	(text "3.3V"
		(exclude_from_sim no)
		(at 111.76 72.39 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "512c753d-64df-4124-a784-3f248fccd656")
	)
	(text "PB2"
		(exclude_from_sim no)
		(at 99.06 69.85 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "543000d1-dcb0-4f58-b538-7c6270e45a8a")
	)
	(text "I2C ACTIVE (YEL)"
		(exclude_from_sim no)
		(at 60.96 117.475 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "5596079f-08bd-4a0f-b230-ea8c41c21f1e")
	)
	(text "CTL2"
		(exclude_from_sim no)
		(at 180.34 66.04 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "5c0d09ae-9ac1-4e08-88bf-cbe691d44337")
	)
	(text "SCL"
		(exclude_from_sim no)
		(at 99.06 64.77 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "5ef0ba63-d068-4e35-b118-6c68c822258e")
	)
	(text "3.3V/GND"
		(exclude_from_sim no)
		(at 87.63 72.39 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "626f073a-0909-4e0f-bd7e-eace60bc1994")
	)
	(text "PD0"
		(exclude_from_sim no)
		(at 167.64 55.88 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "6e7a6a6a-af87-4f82-ab28-8aaf37cd7036")
	)
	(text "PB6"
		(exclude_from_sim no)
		(at 180.34 71.12 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "78aec558-8f43-42f7-94b2-037e08807414")
	)
	(text "PB5"
		(exclude_from_sim no)
		(at 167.64 73.66 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "7efe8167-181d-4688-b892-0070e1b90b68")
	)
	(text "CTL1"
		(exclude_from_sim no)
		(at 167.64 68.58 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "83e40cd0-e1d9-431e-88c8-e56d6f8109dd")
	)
	(text "USBi CONNECTOR"
		(exclude_from_sim no)
		(at 182.88 99.06 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "85173736-1b84-4049-8816-006d9cdfaaa0")
	)
	(text "PB0"
		(exclude_from_sim no)
		(at 99.06 67.31 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "8cafcd01-e16e-4996-bf48-34f44ad345a9")
	)
	(text "PA1"
		(exclude_from_sim no)
		(at 180.34 63.5 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "9246255c-b2f2-438c-8d2f-aafd2fbfaa02")
	)
	(text "GND"
		(exclude_from_sim no)
		(at 111.76 52.07 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "940b7cc5-c20d-43e1-a0a6-68cddacaeb20")
	)
	(text "PA0"
		(exclude_from_sim no)
		(at 167.64 66.04 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "b8d6f7b6-50cf-4dcf-8f8d-86ecaa1ae702")
	)
	(text "PA3"
		(exclude_from_sim no)
		(at 180.34 60.96 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "bfad38f9-0c1a-4318-9ff9-46abd96b15f6")
	)
	(text "JUMP to P1 pin20"
		(exclude_from_sim no)
		(at 80.01 96.52 0)
		(effects
			(font
				(size 2.0066 2.0066)
				(thickness 0.4013)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "ca2e55c6-4185-4e52-b105-d2843bcf57e8")
	)
	(text "PD5"
		(exclude_from_sim no)
		(at 99.06 49.53 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "cbdb94e9-7feb-4da6-b4f8-cbf9eb29aeb0")
	)
	(text "PD2"
		(exclude_from_sim no)
		(at 167.64 53.34 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "cf992832-c8fc-4c97-a7b9-1cc40132eaec")
	)
	(text "GND"
		(exclude_from_sim no)
		(at 95.25 62.23 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "d15fe9d1-163c-4175-9f01-6a18f4528195")
	)
	(text "5V INPUT"
		(exclude_from_sim no)
		(at 219.71 85.09 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "d1967e66-53c8-4ae6-8338-b34e280cac98")
	)
	(text "SDA"
		(exclude_from_sim no)
		(at 111.76 64.77 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "d62d9300-e276-47c3-a7db-c8d93ea9210d")
	)
	(text "SPI ACTIVE (YEL)"
		(exclude_from_sim no)
		(at 60.325 146.05 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "dbd5016f-5e1d-4533-b50b-9ac5909bb748")
	)
	(text "PB3"
		(exclude_from_sim no)
		(at 111.76 69.85 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "dc81f117-bc0d-4455-82a6-e65d9cf12303")
	)
	(text "Some FX2 board has an Non-bootable issue\nCause of I2C SDA voltage droped during boot."
		(exclude_from_sim no)
		(at 66.675 92.71 0)
		(effects
			(font
				(size 1.2192 1.2192)
			)
			(justify left bottom)
		)
		(uuid "e29f6d14-04dc-4e81-85d3-248e80a15677")
	)
	(text "PA2"
		(exclude_from_sim no)
		(at 167.64 63.5 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "e2a5f177-e93e-4547-9b75-4bafee1f7d19")
	)
	(text "PD6"
		(exclude_from_sim no)
		(at 111.76 49.53 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "e3a1bbfa-e061-40bd-b41a-d918fb8c6028")
	)
	(text "GND"
		(exclude_from_sim no)
		(at 95.25 59.69 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "e55372a9-62f9-485d-be0a-1125aedc3acf")
	)
	(text "GPIO LED (BLU)"
		(exclude_from_sim no)
		(at 62.865 131.445 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "ea7ea2f9-d378-43cc-aee5-e0ba3c121280")
	)
	(text "CTL0"
		(exclude_from_sim no)
		(at 180.34 68.58 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "f0f7b1de-9bcb-437e-aede-43008222b502")
	)
	(text "PD4"
		(exclude_from_sim no)
		(at 167.64 50.8 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "f18e855c-82d9-424c-8ced-7067ece23371")
	)
	(text "PA6"
		(exclude_from_sim no)
		(at 167.64 58.42 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "f1b1597b-68e5-4b95-8f6b-9688fc032357")
	)
	(text "RDY1"
		(exclude_from_sim no)
		(at 111.76 57.15 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "f51c375d-4119-44e4-aa4c-6d0b87c8eef8")
	)
	(text "PD7"
		(exclude_from_sim no)
		(at 99.06 52.07 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "f9270a59-3c2d-4271-8e74-3b45db92582d")
	)
	(text "PD3"
		(exclude_from_sim no)
		(at 180.34 50.8 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "f9a0148c-0692-483c-a57b-b0f552a097c2")
	)
	(text "LEFT PIN-HEADER"
		(exclude_from_sim no)
		(at 95.25 40.64 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "f9f0cda4-9f0b-4405-9596-7f6cf2bae5cd")
	)
	(text "CLK"
		(exclude_from_sim no)
		(at 99.06 54.61 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "fb29a904-8791-4b71-b6c4-368ef1b15673")
	)
	(text "PB7"
		(exclude_from_sim no)
		(at 167.64 71.12 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "fd3d9513-eb57-45da-bb65-dd96de02abd0")
	)
	(text "RIGHT PIN-HEADER"
		(exclude_from_sim no)
		(at 163.83 41.91 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "fe763d01-a72c-4e62-bb74-3e617ed744e3")
	)
	(junction
		(at 139.7 106.68)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "01c415a3-a160-4b21-9328-e058a2961314")
	)
	(junction
		(at 139.7 99.06)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "06a75e6a-5e10-42aa-b239-50e3ae102304")
	)
	(junction
		(at 87.63 111.76)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "179bd123-4924-4062-8fdc-c726defadfcc")
	)
	(junction
		(at 143.51 106.68)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "2db1878d-3f14-46ec-bd2a-04847ff5ddf5")
	)
	(junction
		(at 87.63 125.73)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "403812d8-31c2-41af-9fab-3ca23ed894e1")
	)
	(junction
		(at 140.97 54.61)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "438f0e65-bc74-4881-aebf-29b63ba44155")
	)
	(junction
		(at 149.86 106.68)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "54e9be7f-36c5-431a-89f6-b8bf91ee7224")
	)
	(junction
		(at 231.14 106.68)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "74689db4-d7da-4c96-8b2d-f0e1e008c5c0")
	)
	(junction
		(at 55.88 62.23)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "8321c3b8-ad07-4077-a179-403ebd0a1f94")
	)
	(junction
		(at 157.48 114.3)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "87376e52-26da-407a-b38f-26d1a0cfd0e5")
	)
	(junction
		(at 159.385 99.06)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "90ed56bd-748d-4d16-a8ee-201e34a1922d")
	)
	(junction
		(at 243.84 114.3)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "af12dd62-4257-433d-8bb3-5149013a956d")
	)
	(junction
		(at 139.7 114.3)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "bd1768fe-d7c5-482d-982d-d3792a4e9e47")
	)
	(junction
		(at 226.06 73.66)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "c70390bd-7324-4fcf-962e-54679ca9ff7a")
	)
	(junction
		(at 118.11 72.39)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "f984d2c1-9149-488b-9379-ce96363a724c")
	)
	(junction
		(at 87.63 139.7)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "fe2bd29b-e865-43b1-ba51-3a826086ade2")
	)
	(no_connect
		(at 167.64 68.58)
		(uuid "0f693d2d-e646-4a74-bf9e-c4e3738fa770")
	)
	(no_connect
		(at 180.34 68.58)
		(uuid "188d280f-82ee-4057-aa3c-b7047dd999c2")
	)
	(no_connect
		(at 180.34 60.96)
		(uuid "244255d6-630f-44df-8a19-74962ac9a713")
	)
	(no_connect
		(at 111.76 62.23)
		(uuid "39d971f3-e4e3-439e-8033-d1b9f36cc878")
	)
	(no_connect
		(at 111.76 49.53)
		(uuid "3bbadc6c-d7bb-45ac-8451-dc7c3fca3276")
	)
	(no_connect
		(at 167.64 50.8)
		(uuid "3cf7e2f0-6f33-41af-80f8-74e5e1400cb0")
	)
	(no_connect
		(at 99.06 52.07)
		(uuid "4a0c4ba5-98d8-41f4-b554-75135ba8457d")
	)
	(no_connect
		(at 99.06 49.53)
		(uuid "60aefbc9-3548-4b4b-a472-d370262a381d")
	)
	(no_connect
		(at 180.34 50.8)
		(uuid "677236a4-4414-4c63-b667-4e92e06ec36d")
	)
	(no_connect
		(at 180.34 71.12)
		(uuid "740f7629-60c0-4b76-85a9-0b8e779e15e8")
	)
	(no_connect
		(at 180.34 58.42)
		(uuid "87edb612-666b-4f3b-8567-21f3c59f284c")
	)
	(no_connect
		(at 167.64 55.88)
		(uuid "90361327-1955-4ea7-ac87-0ad782e97ea8")
	)
	(no_connect
		(at 167.64 71.12)
		(uuid "93985d5e-19be-4919-b8e9-e0bec0c5fe96")
	)
	(no_connect
		(at 180.34 66.04)
		(uuid "ac7183a1-cbdd-4383-bf0b-715ab00d6766")
	)
	(no_connect
		(at 167.64 53.34)
		(uuid "c2f92f69-8b8f-40b3-9020-3a17be6aaa86")
	)
	(no_connect
		(at 111.76 59.69)
		(uuid "cca2575e-87b7-46ef-bc35-73f670a1b2a7")
	)
	(no_connect
		(at 167.64 60.96)
		(uuid "cf97784a-8c43-46c0-b2fd-ca5deb725a39")
	)
	(no_connect
		(at 180.34 53.34)
		(uuid "d1adb637-6dbe-4f21-ade4-a938baac0091")
	)
	(no_connect
		(at 99.06 72.39)
		(uuid "de5644c2-f741-4a27-a326-d0a9a33d3ef2")
	)
	(no_connect
		(at 111.76 57.15)
		(uuid "e15fc4f4-d046-4290-ad54-99e1353c584f")
	)
	(no_connect
		(at 99.06 57.15)
		(uuid "e7723beb-20bb-4adc-b05e-afd308e9659f")
	)
	(no_connect
		(at 167.64 58.42)
		(uuid "fd209eae-72f0-41a6-b7e4-5bbb02e8d2f3")
	)
	(no_connect
		(at 167.64 73.66)
		(uuid "ff39865f-b973-443f-b5a6-c84b3c9cbf12")
	)
	(wire
		(pts
			(xy 180.34 63.5) (xy 189.23 63.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "089aa714-be1c-4f0f-88e8-23ae9613f223")
	)
	(wire
		(pts
			(xy 55.88 59.69) (xy 99.06 59.69)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "09017ef4-8599-430b-8ce5-069a64f873af")
	)
	(wire
		(pts
			(xy 139.7 106.68) (xy 143.51 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0d79cb87-2874-4817-b907-6a6db3f30915")
	)
	(wire
		(pts
			(xy 219.71 46.99) (xy 219.71 49.53)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0e9a2c43-6f83-4d16-bf27-7c502a1e716a")
	)
	(wire
		(pts
			(xy 140.97 52.07) (xy 140.97 54.61)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0ec40f4d-e2c5-494d-86b6-b52ac61732ce")
	)
	(wire
		(pts
			(xy 180.34 55.88) (xy 189.23 55.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "15322477-e9c9-4514-897b-73223a8c5b3e")
	)
	(wire
		(pts
			(xy 172.72 104.14) (xy 181.61 104.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "15b26625-6e32-4fd5-8597-0f7e3a43b6d4")
	)
	(wire
		(pts
			(xy 231.14 102.87) (xy 231.14 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "161c380b-25d8-4dd0-99f5-3acdc2c6bb0f")
	)
	(wire
		(pts
			(xy 139.7 90.17) (xy 139.7 99.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "177db4e1-839b-4d32-abfc-ac9fd37be873")
	)
	(wire
		(pts
			(xy 55.88 59.69) (xy 55.88 62.23)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "187eb91d-e218-4c6a-a49d-ffe81006cd11")
	)
	(wire
		(pts
			(xy 223.52 73.66) (xy 226.06 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "18f7493f-5dff-4a76-82c5-ee257a352d09")
	)
	(wire
		(pts
			(xy 194.31 109.22) (xy 209.55 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1a2ad648-34d0-49fb-9eab-0350e0d51ada")
	)
	(wire
		(pts
			(xy 60.96 139.7) (xy 63.5 139.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1a878809-d85d-4f11-81a2-9693b110ef53")
	)
	(wire
		(pts
			(xy 118.11 82.55) (xy 118.11 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1b4561bd-bc8b-4a13-850a-dc4150117a5a")
	)
	(wire
		(pts
			(xy 81.28 111.76) (xy 87.63 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1c93546c-c150-442e-8995-13c5457f16f7")
	)
	(wire
		(pts
			(xy 73.66 69.85) (xy 99.06 69.85)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1e2540aa-4f69-4fa2-a92e-937b7b61eed3")
	)
	(wire
		(pts
			(xy 58.42 153.67) (xy 58.42 158.75)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1ebba305-1b91-4920-9a64-51c276b4025c")
	)
	(wire
		(pts
			(xy 181.61 130.81) (xy 129.54 130.81)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1ec3199d-900b-4d52-b0ad-ccc7423f72b9")
	)
	(wire
		(pts
			(xy 71.12 153.67) (xy 72.39 153.67)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1eccf6b6-8313-44a7-8e1c-57bc730ad0bc")
	)
	(wire
		(pts
			(xy 154.94 114.3) (xy 157.48 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "21969a61-cc5e-4052-b27a-7b486ce05276")
	)
	(wire
		(pts
			(xy 160.02 63.5) (xy 167.64 63.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "25b8e5dc-8d88-42b4-9e2a-e0c03cda4782")
	)
	(wire
		(pts
			(xy 157.48 123.19) (xy 157.48 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "27e955a3-cac3-4121-95e5-b78a7f4f09e8")
	)
	(wire
		(pts
			(xy 175.26 125.73) (xy 175.26 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2e72b9eb-ba09-43fa-b116-d3f1af8c8708")
	)
	(wire
		(pts
			(xy 177.8 128.27) (xy 129.54 128.27)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "300c561c-a8c0-4eba-9a65-fd9939d0aaeb")
	)
	(wire
		(pts
			(xy 194.31 114.3) (xy 243.84 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "38f207f7-e022-46be-824e-2b8dad175325")
	)
	(wire
		(pts
			(xy 132.08 102.87) (xy 132.08 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3e238a29-219c-43c5-8f09-43ac5671fe38")
	)
	(wire
		(pts
			(xy 99.06 64.77) (xy 73.66 64.77)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "45aa6f73-cc51-4688-ba8c-33ef75ddb3ce")
	)
	(wire
		(pts
			(xy 139.7 114.3) (xy 144.78 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4b7e2249-61d5-4b83-929b-736e1c828931")
	)
	(wire
		(pts
			(xy 175.26 109.22) (xy 181.61 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "500ef4fe-cf84-4136-9d1b-788d19475ff5")
	)
	(wire
		(pts
			(xy 154.94 99.06) (xy 159.385 99.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "542033fe-50a0-464e-9691-93d053ee12d2")
	)
	(wire
		(pts
			(xy 129.54 99.06) (xy 139.7 99.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "54495771-902f-45ed-8d3f-982a15ab7dde")
	)
	(wire
		(pts
			(xy 55.88 62.23) (xy 99.06 62.23)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "575cb34f-b792-4560-a708-e6cb27e34ae5")
	)
	(wire
		(pts
			(xy 60.96 125.73) (xy 63.5 125.73)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "583eab95-6228-47b9-a83e-9aaa730a4774")
	)
	(wire
		(pts
			(xy 159.385 99.06) (xy 172.72 99.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5a9a7b98-96f6-4ff3-9829-c31959356158")
	)
	(polyline
		(pts
			(xy 111.125 95.25) (xy 108.585 95.25)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "5e3183cc-687f-4bf0-b162-f6efc22b1b42")
	)
	(wire
		(pts
			(xy 233.68 73.66) (xy 233.68 69.85)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5f1f4357-b618-418f-931d-bcc44ed33d44")
	)
	(wire
		(pts
			(xy 151.13 123.19) (xy 157.48 123.19)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "66fe3fcf-3ee7-40b6-991f-95c2458b9b28")
	)
	(wire
		(pts
			(xy 111.76 54.61) (xy 140.97 54.61)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6aa6bea9-5fec-41b1-b983-97517517f675")
	)
	(wire
		(pts
			(xy 151.13 90.17) (xy 159.385 90.17)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6ab77214-090c-42be-984f-da79ac4851b3")
	)
	(wire
		(pts
			(xy 111.76 72.39) (xy 118.11 72.39)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6c483a38-630d-4dce-be23-a30ec332e6bc")
	)
	(wire
		(pts
			(xy 85.09 67.31) (xy 99.06 67.31)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6d51fc78-5783-4545-98c8-22c0c56281e2")
	)
	(wire
		(pts
			(xy 87.63 153.67) (xy 80.01 153.67)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6f7cc8d7-2521-4a10-a746-8ab43dd5ff85")
	)
	(wire
		(pts
			(xy 172.72 99.06) (xy 172.72 104.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7293aa7e-22f6-4286-95c6-81de58a2ead8")
	)
	(wire
		(pts
			(xy 143.51 106.68) (xy 149.86 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7d0f0283-647c-4b53-b605-b1b51d3e5b17")
	)
	(wire
		(pts
			(xy 71.12 139.7) (xy 73.66 139.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "800153e1-a17a-4a56-bbaf-1b5de18a3535")
	)
	(wire
		(pts
			(xy 87.63 111.76) (xy 87.63 104.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "82be90e3-8981-41ca-8cd3-3897e300af93")
	)
	(wire
		(pts
			(xy 172.72 106.68) (xy 181.61 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "83663f84-5756-433f-abfb-d4704895fdc5")
	)
	(wire
		(pts
			(xy 111.76 52.07) (xy 140.97 52.07)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "86622cdc-9fac-4b4a-a6a3-6e3204aae446")
	)
	(wire
		(pts
			(xy 231.14 49.53) (xy 232.41 49.53)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "88b9f668-bbbc-4f05-b24c-1c08776e2e26")
	)
	(polyline
		(pts
			(xy 118.11 101.6) (xy 111.125 95.25)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "8b188bed-81a2-41c4-a442-7a9e0a0054ac")
	)
	(wire
		(pts
			(xy 194.31 104.14) (xy 209.55 104.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8b8e14bd-b9cf-4cab-a582-9bddb6c4bfd5")
	)
	(wire
		(pts
			(xy 71.12 111.76) (xy 73.66 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8f48036f-cc1e-4eb4-8cc3-38c656e91cb0")
	)
	(wire
		(pts
			(xy 143.51 115.57) (xy 143.51 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8fba33c8-1df2-4641-b253-487ccf7896b8")
	)
	(wire
		(pts
			(xy 226.06 73.66) (xy 233.68 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "91d567a5-4fa9-4fc8-8b56-5669ddde50ba")
	)
	(wire
		(pts
			(xy 73.66 67.31) (xy 77.47 67.31)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "95918e6c-a92f-46b3-9164-81869128c36c")
	)
	(wire
		(pts
			(xy 81.28 125.73) (xy 87.63 125.73)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "985042f9-238c-4458-8661-675dd3913ae8")
	)
	(wire
		(pts
			(xy 223.52 76.2) (xy 233.68 76.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "99814b7a-0dd0-40b2-8dc7-1a6ead4f714a")
	)
	(wire
		(pts
			(xy 181.61 114.3) (xy 181.61 130.81)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9ab152e5-1354-4463-aafa-0f21385dd9f2")
	)
	(wire
		(pts
			(xy 73.66 54.61) (xy 77.47 54.61)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9f6f00ed-dfb8-466d-a95c-db23fc16e240")
	)
	(wire
		(pts
			(xy 132.08 106.68) (xy 139.7 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a15f8d1f-a513-452c-8f5a-c157ba050e31")
	)
	(wire
		(pts
			(xy 85.09 54.61) (xy 99.06 54.61)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a18e3c76-74d4-4e70-8ce0-e02780dfa850")
	)
	(wire
		(pts
			(xy 159.385 90.17) (xy 159.385 99.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a1bfeed2-5f4f-4002-9b33-397a1825c2fa")
	)
	(wire
		(pts
			(xy 140.97 90.17) (xy 139.7 90.17)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a471f7ee-ea69-471a-8115-3d94f320104d")
	)
	(wire
		(pts
			(xy 157.48 114.3) (xy 172.72 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a770d57f-65e5-4d1d-beed-950926ba0252")
	)
	(wire
		(pts
			(xy 231.14 46.99) (xy 231.14 49.53)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "aa37a51b-80c6-4fd5-b84e-037cd4917c78")
	)
	(wire
		(pts
			(xy 129.54 125.73) (xy 175.26 125.73)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b0676daf-366f-4ba3-a387-7d2cff628a2b")
	)
	(wire
		(pts
			(xy 87.63 111.76) (xy 87.63 125.73)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b33c6b9f-a552-4467-b8b0-36e502b3ce8b")
	)
	(wire
		(pts
			(xy 140.97 123.19) (xy 139.7 123.19)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b345d1bf-6ee3-4647-80a0-205aa030f583")
	)
	(wire
		(pts
			(xy 55.88 62.23) (xy 55.88 64.135)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b487e8c9-580f-474f-ba35-da34ef184655")
	)
	(wire
		(pts
			(xy 143.51 97.79) (xy 143.51 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b66a2e91-d873-4742-a52f-0ee764d47b5a")
	)
	(wire
		(pts
			(xy 139.7 99.06) (xy 144.78 99.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b7956424-7491-4e21-9dd7-1723a92f6711")
	)
	(wire
		(pts
			(xy 231.14 106.68) (xy 236.22 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "baaba87a-1377-4ac6-8575-d4a079712e0f")
	)
	(wire
		(pts
			(xy 87.63 125.73) (xy 87.63 139.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bd7f110b-cbe1-4722-ab1f-b3b6af65fffb")
	)
	(wire
		(pts
			(xy 226.06 71.12) (xy 226.06 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bfde6ec9-af82-4a62-ad5e-c4db5fc173a1")
	)
	(wire
		(pts
			(xy 58.42 153.67) (xy 63.5 153.67)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bfed16aa-858d-4cf0-954c-b6b35da56107")
	)
	(wire
		(pts
			(xy 111.76 69.85) (xy 129.54 69.85)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c568ac01-a30d-4a82-9498-e14c1b4eee6e")
	)
	(wire
		(pts
			(xy 233.68 76.2) (xy 233.68 80.01)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c7c60e8b-6e8f-4e6e-9820-4a3c6e2c3232")
	)
	(wire
		(pts
			(xy 194.31 111.76) (xy 210.82 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c875f85b-5dce-492b-81e7-ad6812f4804b")
	)
	(wire
		(pts
			(xy 177.8 111.76) (xy 177.8 128.27)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c901216d-49a5-4f3c-8efe-a3f058c61c57")
	)
	(wire
		(pts
			(xy 125.095 102.87) (xy 132.08 102.87)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c99c64cf-a1a2-46f4-806b-935683e9b098")
	)
	(wire
		(pts
			(xy 111.76 64.77) (xy 129.54 64.77)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ca6b67c2-417b-4f95-8337-ed6c77336979")
	)
	(wire
		(pts
			(xy 71.12 125.73) (xy 73.66 125.73)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ce105c1e-5a5f-4e8e-9363-8ab2613efd27")
	)
	(wire
		(pts
			(xy 87.63 139.7) (xy 81.28 139.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cf9118e1-2622-420b-bbaf-ae2891726d56")
	)
	(wire
		(pts
			(xy 167.64 66.04) (xy 160.02 66.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cfc18610-6691-4b0f-aede-245167bac2df")
	)
	(wire
		(pts
			(xy 118.11 72.39) (xy 128.27 72.39)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d35578bd-1285-438b-85da-efee735c9a83")
	)
	(wire
		(pts
			(xy 243.84 106.68) (xy 243.84 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d533a3d4-761b-40af-96cc-9b5a9ec78842")
	)
	(wire
		(pts
			(xy 194.31 106.68) (xy 231.14 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d80d749a-54eb-4851-93cb-ab97175d6b8b")
	)
	(wire
		(pts
			(xy 177.8 111.76) (xy 181.61 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d955d3c0-9f15-4ab7-a776-c52dcab7ea34")
	)
	(wire
		(pts
			(xy 172.72 114.3) (xy 172.72 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e350e5b5-1e28-430b-9797-1a9bf0dfd492")
	)
	(wire
		(pts
			(xy 111.76 67.31) (xy 129.54 67.31)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e59d49f0-11b0-4f9b-ba1a-60b6bf4f508a")
	)
	(wire
		(pts
			(xy 139.7 123.19) (xy 139.7 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e6704e8c-a391-4e46-a596-5205ececfae4")
	)
	(wire
		(pts
			(xy 243.84 114.3) (xy 243.84 116.205)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e89767c7-21b7-4b54-a9f0-6dfd4f2cc1a4")
	)
	(wire
		(pts
			(xy 167.64 106.68) (xy 167.64 107.95)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ed0f403a-d8c6-4e26-b5ba-562738f1bb1c")
	)
	(wire
		(pts
			(xy 129.54 114.3) (xy 139.7 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "edd61f82-29fc-4d65-b4ce-748e7f55aa7a")
	)
	(wire
		(pts
			(xy 163.83 106.68) (xy 167.64 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ee410c80-7235-46b3-b2bd-899fd373f6c6")
	)
	(wire
		(pts
			(xy 118.11 72.39) (xy 118.11 74.93)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f04f2830-d2f1-48b5-be9e-034a6454a9de")
	)
	(wire
		(pts
			(xy 140.97 54.61) (xy 140.97 57.15)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f1318a74-f18a-49ef-94ea-ba4f61e69039")
	)
	(wire
		(pts
			(xy 87.63 139.7) (xy 87.63 153.67)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f39fe139-b3dd-47f8-9251-ae311778bab5")
	)
	(wire
		(pts
			(xy 60.96 111.76) (xy 63.5 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f73e81e0-d17f-427c-90db-bd184326087c")
	)
	(wire
		(pts
			(xy 149.86 106.68) (xy 156.21 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fd46dfb0-9c91-49b9-9612-745b2724738a")
	)
	(wire
		(pts
			(xy 180.34 73.66) (xy 189.23 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "feb510de-a024-4db2-b21a-998eca4b5add")
	)
	(global_label "CCLK"
		(shape output)
		(at 189.23 55.88 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left)
		)
		(uuid "00adb811-3679-4c68-bfb1-6d9e33051505")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 189.23 55.88 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "CDATA"
		(shape input)
		(at 210.82 111.76 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left)
		)
		(uuid "1e84962c-a6a0-4975-a322-e27a4dc3eb9e")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 210.82 111.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "SCL"
		(shape bidirectional)
		(at 129.54 99.06 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "32d4ecbb-6466-4de2-a8c2-9917713ecf1c")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 129.54 99.06 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "LED_2"
		(shape input)
		(at 60.96 125.73 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "376e0d48-9d8e-46d6-8b43-3063f7d25782")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 60.96 125.73 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "LED_2"
		(shape output)
		(at 73.66 69.85 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "3ad32717-6d03-438a-8bc9-d45d4d3da21f")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 73.66 69.85 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "SDA"
		(shape bidirectional)
		(at 129.54 64.77 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left)
		)
		(uuid "3fb0bfbe-142d-4897-ad7d-eedc3b38405a")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 129.54 64.77 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "LED_3"
		(shape input)
		(at 60.96 139.7 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "58ba549d-9da4-45e1-bfb1-844d625a382a")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 60.96 139.7 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "USB_CLK"
		(shape input)
		(at 209.55 104.14 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left)
		)
		(uuid "5a52a76b-0903-46a1-8b60-f68a05ad5ff4")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 209.55 104.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "COUT"
		(shape output)
		(at 189.23 63.5 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left)
		)
		(uuid "64cde808-c377-441a-88c4-df03e3023ab3")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 189.23 63.5 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "SDA"
		(shape bidirectional)
		(at 129.54 114.3 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "66102b81-e903-413f-b2c4-1134a2cab1d2")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 129.54 114.3 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "CCLK"
		(shape input)
		(at 129.54 128.27 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "76e91010-7f48-4437-8177-fdef4d9e1722")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 129.54 128.27 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "BRD_~{RESET}"
		(shape input)
		(at 209.55 109.22 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left)
		)
		(uuid "7b3efbfe-818d-40fc-b5ac-c2fe747b3ab9")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 209.55 109.22 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "BRD_~{RESET}"
		(shape output)
		(at 73.66 67.31 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "822dd661-e5de-4010-ace6-9c8b4d325ea2")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 73.66 67.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "USB_CLK"
		(shape output)
		(at 73.66 54.61 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "8a08f88f-a5cf-469b-9ff1-e406aaf0cafc")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 73.66 54.61 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "SCL"
		(shape bidirectional)
		(at 73.66 64.77 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "ac0a3293-d971-45bd-b684-78f829ca1ace")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 73.66 64.77 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "USB_PWR_ON"
		(shape output)
		(at 189.23 73.66 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left)
		)
		(uuid "ac10c90a-66bd-4a4e-937e-29e2d8843648")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 189.23 73.66 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "LED_3"
		(shape output)
		(at 129.54 69.85 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left)
		)
		(uuid "c55e9e97-2d30-4d22-9996-9e9aff4e36ad")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 129.54 69.85 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{CLATCH1}"
		(shape output)
		(at 160.02 63.5 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "c5a547bc-cd9e-408d-9370-ee46affda90e")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 160.02 63.5 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{CLATCH1}"
		(shape input)
		(at 129.54 130.81 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "c968caa9-2d77-4f25-8728-758530b2362c")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 129.54 130.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "COUT"
		(shape input)
		(at 129.54 125.73 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "cf70a1b9-c6e0-453d-a048-3aa4ee58bc9b")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 129.54 125.73 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "LED_1"
		(shape input)
		(at 60.96 111.76 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "d387d68c-c0a3-4e60-9cca-69d963a0a0e8")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 60.96 111.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "CDATA"
		(shape output)
		(at 160.02 66.04 180)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify right)
		)
		(uuid "db61a951-617e-4686-b6cd-d236cdb51aeb")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 160.02 66.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "LED_1"
		(shape output)
		(at 129.54 67.31 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left)
		)
		(uuid "fcb7a1e4-cacd-4bce-b33d-6b105ec5098f")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 129.54 67.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(symbol
		(lib_id "USBi_Programmer-rescue:Conn_02x10_Odd_Even-conn")
		(at 104.14 59.69 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dc68f9")
		(property "Reference" "P1"
			(at 104.14 45.72 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "CONN_02X10"
			(at 104.775 43.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "fdsp_pinheader:Pin_Header_Straight_2x10"
			(at 104.14 90.17 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 104.14 90.17 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 104.14 59.69 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "f318c1b1-9793-4cf5-8c6c-3eda10b34786")
		)
		(pin "3"
			(uuid "72411e87-56cd-4694-a734-8b8b7e03f99e")
		)
		(pin "5"
			(uuid "1acdf14f-c48a-4bbb-80fa-65edb623f4fc")
		)
		(pin "7"
			(uuid "4eb48b8a-f62f-4d55-a29b-d6f03dd8fa62")
		)
		(pin "9"
			(uuid "3c7300ad-5bfb-4d9b-9309-71b9d5f2b17b")
		)
		(pin "11"
			(uuid "ab057172-79a1-46e9-9a78-00fe245d0053")
		)
		(pin "13"
			(uuid "c63c1ada-06f7-4937-8c95-b2b57d77fa7b")
		)
		(pin "15"
			(uuid "22d2d29a-449e-49a4-acc2-2b2a871233b0")
		)
		(pin "17"
			(uuid "eeb141b7-b891-4e7d-914d-8989b3d1d17e")
		)
		(pin "19"
			(uuid "515b56cd-ed7e-4971-8852-9e4ecbbf1490")
		)
		(pin "2"
			(uuid "3ab1e5f6-c843-4724-a0cc-036de60aa54e")
		)
		(pin "4"
			(uuid "dfa43e89-ac4e-441b-b88b-de9a6902b678")
		)
		(pin "6"
			(uuid "046a1ccd-e596-4b98-abd4-a1fb12fcf74d")
		)
		(pin "8"
			(uuid "9592fa7a-57ee-4dda-aa09-03e73cf54970")
		)
		(pin "10"
			(uuid "1881f052-7c83-48b2-8f69-6b02b39a774a")
		)
		(pin "12"
			(uuid "7644fd1e-4244-4ec2-a600-8fdc2a5e1b37")
		)
		(pin "14"
			(uuid "0d8082ef-1e39-47bd-a516-218340ec3226")
		)
		(pin "16"
			(uuid "e4c32128-be0f-4a49-9689-676630b877e1")
		)
		(pin "18"
			(uuid "2794c57e-2fe7-41ae-bab5-469044d5651f")
		)
		(pin "20"
			(uuid "7bde4310-833b-4a24-b5fd-cd1680236833")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "P1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "USBi_Programmer-rescue:Conn_02x10_Odd_Even-conn")
		(at 172.72 60.96 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dc6a0d")
		(property "Reference" "P4"
			(at 172.72 46.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "CONN_02X10"
			(at 173.99 44.45 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "fdsp_pinheader:Pin_Header_Straight_2x10"
			(at 172.72 91.44 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 172.72 91.44 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 172.72 60.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "8f7bdb70-07ba-4dd1-8207-29422e65159c")
		)
		(pin "3"
			(uuid "fc943601-608e-4fee-9889-bcb1d0a71304")
		)
		(pin "5"
			(uuid "d21ac226-4e84-4d79-967e-02f3b40e1b19")
		)
		(pin "7"
			(uuid "db6cca47-f52a-4402-aca1-358a4d6cfb3a")
		)
		(pin "9"
			(uuid "35f6795b-4ffd-4a94-8f69-9cb85b890d44")
		)
		(pin "11"
			(uuid "1194f591-34e8-47c4-be93-ea1965f5fe7e")
		)
		(pin "13"
			(uuid "81dbf5f9-f39d-474d-9ffc-e672bc057dd8")
		)
		(pin "15"
			(uuid "3f621bec-f3b1-4f9f-a8a1-bf9259ad699b")
		)
		(pin "17"
			(uuid "1e9dd15c-5948-4a3d-bfbd-d4f7f58576d0")
		)
		(pin "19"
			(uuid "b4be81f8-c1ad-4f45-b52d-8ae0732c41c8")
		)
		(pin "2"
			(uuid "6db46e79-46ab-422e-b6e5-42def00d4ced")
		)
		(pin "4"
			(uuid "93dcd6b8-eb09-4601-855c-b47efd45f112")
		)
		(pin "6"
			(uuid "6c6d34fd-e539-43c3-8cad-c527d89113c0")
		)
		(pin "8"
			(uuid "13d1a0ac-f629-4c43-ab2f-dd91ef94fe2c")
		)
		(pin "10"
			(uuid "9c992bae-0612-4982-b888-03bc8875fe3d")
		)
		(pin "12"
			(uuid "66882c76-80e2-4ebf-83cd-9c7a2f9636e7")
		)
		(pin "14"
			(uuid "52eae0c6-a204-4952-aa08-b4cb6f0c80ab")
		)
		(pin "16"
			(uuid "b96c5462-23c9-4fdd-a1e0-5162c3eab560")
		)
		(pin "18"
			(uuid "4de6462e-8e7e-467e-af9d-214bab66668d")
		)
		(pin "20"
			(uuid "a981f292-e0bb-49bb-84a7-c77cbf62a259")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "P4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Connector_Generic:Conn_02x05_Odd_Even")
		(at 186.69 109.22 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dc6f72")
		(property "Reference" "P2"
			(at 186.69 101.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "CONN_02X05"
			(at 189.23 116.84 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "fdsp_connector:IDC_Header_Straight_10pins"
			(at 186.69 139.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 186.69 139.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 186.69 109.22 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "bf61b683-2bfb-4360-a6e3-08c4e1f86437")
		)
		(pin "3"
			(uuid "a922d6c8-39c9-47cb-a23d-987d4d94be7b")
		)
		(pin "5"
			(uuid "171ddfd5-5627-4ab7-919a-40ffee9eafa1")
		)
		(pin "7"
			(uuid "3785357c-5b60-4f59-a685-488543f623cb")
		)
		(pin "9"
			(uuid "b704be58-fc5f-426f-b52c-4f0e52c63c32")
		)
		(pin "2"
			(uuid "938f9d82-6dfa-46b6-9e6d-8262cf48903c")
		)
		(pin "4"
			(uuid "24866f63-0cc2-4830-adaa-4b21552cd7a8")
		)
		(pin "6"
			(uuid "05fea8ef-1d68-4c15-b116-ae02ec9c47a4")
		)
		(pin "8"
			(uuid "65ee3b5a-f0b6-4ff3-86ca-c0dabbcf57a7")
		)
		(pin "10"
			(uuid "e5ee0800-b432-43e7-b2a6-ee24e860cf64")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "P2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:+5VD")
		(at 231.14 102.87 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dc7349")
		(property "Reference" "#PWR01"
			(at 231.14 106.68 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+5VD"
			(at 231.14 99.314 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 231.14 102.87 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 231.14 102.87 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 231.14 102.87 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "0c6f9b19-1f37-4768-918b-d50d81dfae3e")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR01")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R")
		(at 81.28 54.61 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dc7a7d")
		(property "Reference" "R1"
			(at 81.28 56.642 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "49R9"
			(at 81.28 54.61 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "MyFootprints:Resistor_SMD+THTuniversal_0603to0805_RM7.5_HandSoldering_RevA_Date25Jun2010"
			(at 81.28 52.832 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 81.28 54.61 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 81.28 54.61 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "0cb09ee3-11c4-4275-b9ea-55556554f468")
		)
		(pin "2"
			(uuid "edade616-c2f4-4a36-af1e-eeff37d9ec77")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "R1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R")
		(at 81.28 67.31 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dc842c")
		(property "Reference" "R2"
			(at 81.28 69.215 90)
			(effects
				(font
					(size 1.0922 1.0922)
				)
			)
		)
		(property "Value" "470R"
			(at 81.28 67.31 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "MyFootprints:Resistor_SMD+THTuniversal_0603to0805_RM7.5_HandSoldering_RevA_Date25Jun2010"
			(at 81.28 65.532 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 81.28 67.31 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 81.28 67.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "d6c7bb74-cfd1-4746-aa57-9c82519e9408")
		)
		(pin "2"
			(uuid "663687ac-5b17-4200-97d8-3d03b98d7b91")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "R2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:+5VD")
		(at 233.68 69.85 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dc9f7b")
		(property "Reference" "#PWR02"
			(at 233.68 73.66 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+5VD"
			(at 234.95 64.77 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 233.68 69.85 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 233.68 69.85 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 233.68 69.85 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "b42f822f-ddb1-4068-871e-50be3ccf491d")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR02")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:PWR_FLAG")
		(at 226.06 71.12 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dc9fd7")
		(property "Reference" "#FLG03"
			(at 226.06 68.707 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 226.06 66.548 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 226.06 71.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 226.06 71.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 226.06 71.12 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "623372f1-b6e3-4f19-a6d3-29aaf4d122b3")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#FLG03")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:LED")
		(at 77.47 111.76 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dca6c7")
		(property "Reference" "D1"
			(at 77.47 109.22 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "LED"
			(at 77.47 114.3 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "LEDs:LED_D3.0mm"
			(at 77.47 111.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 77.47 111.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 77.47 111.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "56cfc2ea-aab5-4d65-bb8c-7ba5caee057e")
		)
		(pin "2"
			(uuid "d4f75e74-736d-47d6-98a9-e03a7837fa55")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "D1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:LED")
		(at 77.47 125.73 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dca733")
		(property "Reference" "D2"
			(at 77.47 123.19 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "LED"
			(at 77.47 128.27 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "LEDs:LED_D3.0mm"
			(at 77.47 125.73 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 77.47 125.73 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 77.47 125.73 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "b41ffdbf-af54-4cc7-bb53-b57817442a9b")
		)
		(pin "2"
			(uuid "44224dd5-2f07-4b2f-bcd7-a5cd4eb365f8")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "D2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:LED")
		(at 77.47 139.7 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dca7a3")
		(property "Reference" "D3"
			(at 77.47 137.16 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "LED"
			(at 77.47 142.24 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "LEDs:LED_D3.0mm"
			(at 77.47 139.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 77.47 139.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 77.47 139.7 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "2f331800-403e-4abb-9625-256d6dcdfd93")
		)
		(pin "2"
			(uuid "a801ea39-e043-454f-af8d-c6a1e122918f")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "D3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R")
		(at 67.31 111.76 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dca80b")
		(property "Reference" "R5"
			(at 67.31 113.792 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "470R"
			(at 67.31 111.76 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "MyFootprints:Resistor_SMD+THTuniversal_0603to0805_RM7.5_HandSoldering_RevA_Date25Jun2010"
			(at 67.31 109.982 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 67.31 111.76 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 67.31 111.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "bd9a58da-eb0a-4db1-b24b-27cbf2459926")
		)
		(pin "2"
			(uuid "9a8e8763-c383-4faa-94ef-d4e9c66aad9a")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "R5")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R")
		(at 67.31 125.73 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dcb6ed")
		(property "Reference" "R6"
			(at 67.31 127.762 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "470R"
			(at 67.31 125.73 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "MyFootprints:Resistor_SMD+THTuniversal_0603to0805_RM7.5_HandSoldering_RevA_Date25Jun2010"
			(at 67.31 123.952 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 67.31 125.73 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 67.31 125.73 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "6457410b-cda4-444f-8c44-6fce0b5601c7")
		)
		(pin "2"
			(uuid "685d4555-4d3b-49d2-a813-85967c92844c")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "R6")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R")
		(at 67.31 139.7 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dcb761")
		(property "Reference" "R7"
			(at 67.31 141.732 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "470R"
			(at 67.31 139.7 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "MyFootprints:Resistor_SMD+THTuniversal_0603to0805_RM7.5_HandSoldering_RevA_Date25Jun2010"
			(at 67.31 137.922 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 67.31 139.7 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 67.31 139.7 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "dbb27eac-aa27-4401-9a36-2e0d279bae8c")
		)
		(pin "2"
			(uuid "7fdc7ad2-6b5e-4231-8e79-50319774eb33")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "R7")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:CP")
		(at 240.03 106.68 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dd3110")
		(property "Reference" "C1"
			(at 237.49 104.14 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "100u"
			(at 246.38 104.14 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "Capacitors_Elko_ThroughHole:Elko_vert_11.2x6.3mm_RM2.5_CopperClear"
			(at 243.84 105.7148 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 240.03 106.68 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 240.03 106.68 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "c280b1c3-5be7-4a00-b077-cd314776ce34")
		)
		(pin "2"
			(uuid "d7ea0632-230c-49ae-aad9-3ae2b6fe1a40")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "C1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 140.97 57.15 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dd3fb0")
		(property "Reference" "#PWR04"
			(at 140.97 63.5 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 140.97 60.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 140.97 57.15 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 140.97 57.15 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 140.97 57.15 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "ba8b515b-a99a-4f61-bcaa-f5c3157f52af")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR04")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:Q_NMOS_SGD")
		(at 149.86 101.6 270)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dd9079")
		(property "Reference" "Q1"
			(at 157.48 100.33 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right bottom)
			)
		)
		(property "Value" "Q_NMOS_DGS"
			(at 167.005 102.87 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" "TO_SOT_Packages_THT:TO-92_Inline_Narrow_Oval"
			(at 152.4 96.52 0)
			(effects
				(font
					(size 0.7366 0.7366)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 149.86 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 149.86 101.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "2"
			(uuid "6682f1c8-7de4-4761-9303-f3d463f0fd9d")
		)
		(pin "3"
			(uuid "8c60633a-25fd-4488-b2c1-62e58cfee936")
		)
		(pin "1"
			(uuid "e56d10d0-a111-4a88-9c35-821f1eba798a")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "Q1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R")
		(at 139.7 102.87 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dd963c")
		(property "Reference" "R3"
			(at 141.732 102.87 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k"
			(at 139.7 102.87 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "MyFootprints:Resistor_SMD+THTuniversal_0603to0805_RM7.5_HandSoldering_RevA_Date25Jun2010"
			(at 137.922 102.87 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 139.7 102.87 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 139.7 102.87 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "62b81bfb-721e-4e7b-9017-08949834ace4")
		)
		(pin "2"
			(uuid "f0064ced-3091-4ab5-8004-8aad3c6f61c2")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "R3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:Q_NMOS_SGD")
		(at 149.86 111.76 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dd9a11")
		(property "Reference" "Q2"
			(at 155.575 113.03 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right bottom)
			)
		)
		(property "Value" "Q_NMOS_DGS"
			(at 170.815 115.57 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" "TO_SOT_Packages_THT:TO-92_Inline_Narrow_Oval"
			(at 152.4 116.84 0)
			(effects
				(font
					(size 0.7366 0.7366)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 149.86 111.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 149.86 111.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "2"
			(uuid "c7202094-daa0-4572-b299-2c2d57e3057e")
		)
		(pin "3"
			(uuid "826ef861-3b42-4f94-ab73-e6dee1f28e20")
		)
		(pin "1"
			(uuid "9b34e1bf-30b2-4e54-9d8b-d74bdaa43d59")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "Q2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R")
		(at 139.7 110.49 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dd9b84")
		(property "Reference" "R4"
			(at 141.732 110.49 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k"
			(at 139.7 110.49 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "MyFootprints:Resistor_SMD+THTuniversal_0603to0805_RM7.5_HandSoldering_RevA_Date25Jun2010"
			(at 137.922 110.49 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 139.7 110.49 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 139.7 110.49 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "0e033e98-a2e5-4278-ba89-4858fc2e2e66")
		)
		(pin "2"
			(uuid "354133e8-4d39-4ec1-abcf-e7493f08ce05")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "R4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 243.84 116.205 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055de15ff")
		(property "Reference" "#PWR05"
			(at 243.84 122.555 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 243.84 120.015 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 243.84 116.205 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 243.84 116.205 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 243.84 116.205 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "8f3689de-8474-4a1e-ab8c-4024be71e175")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR05")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 55.88 64.135 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055de1b46")
		(property "Reference" "#PWR06"
			(at 55.88 70.485 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 55.88 67.945 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 55.88 64.135 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 55.88 64.135 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 55.88 64.135 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "85a46491-1afb-4c2e-b5a9-212c40abc2fb")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR06")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R")
		(at 67.31 153.67 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055de295d")
		(property "Reference" "R9"
			(at 67.31 155.702 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "470R"
			(at 67.31 153.67 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "MyFootprints:Resistor_SMD+THTuniversal_0603to0805_RM7.5_HandSoldering_RevA_Date25Jun2010"
			(at 67.31 151.892 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 67.31 153.67 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 67.31 153.67 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "02ff8410-1ddc-4155-bac1-9c6ec64e7e46")
		)
		(pin "2"
			(uuid "bb57fd7a-7bfe-4d92-b80d-85aa1748a51f")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "R9")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:LED")
		(at 76.2 153.67 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055de29fa")
		(property "Reference" "D4"
			(at 76.2 151.13 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "LED"
			(at 76.2 156.21 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "LEDs:LED_D3.0mm"
			(at 76.2 153.67 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 76.2 153.67 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 76.2 153.67 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "8e4c0fe1-e6a1-4cc7-b4e5-804da296afbd")
		)
		(pin "2"
			(uuid "c9330d40-7111-42bc-bdbc-7255e98ab437")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "D4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 58.42 158.75 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055de2bd6")
		(property "Reference" "#PWR07"
			(at 58.42 165.1 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 58.42 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 58.42 158.75 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 58.42 158.75 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 58.42 158.75 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "da45c192-d3f6-4a62-8c46-21709d929e58")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR07")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:+3.3V")
		(at 128.27 72.39 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055de5316")
		(property "Reference" "#PWR08"
			(at 124.46 72.39 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 130.81 71.755 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left top)
			)
		)
		(property "Footprint" ""
			(at 128.27 72.39 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 128.27 72.39 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 128.27 72.39 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "dbcf71a6-82d5-4c5a-b359-fda78aba5ce8")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR08")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:+3.3V")
		(at 87.63 104.14 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055dee244")
		(property "Reference" "#PWR09"
			(at 87.63 107.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 84.455 99.695 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left top)
			)
		)
		(property "Footprint" ""
			(at 87.63 104.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 87.63 104.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 87.63 104.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "a06d61c6-a762-495e-9373-bb9e9e5e0a0e")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR09")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 167.64 107.95 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055df0ae2")
		(property "Reference" "#PWR010"
			(at 167.64 114.3 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 167.64 111.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 167.64 107.95 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 167.64 107.95 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 167.64 107.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "2ba61677-1f83-42b0-8035-00f3de1acdcd")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR010")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R")
		(at 160.02 106.68 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055df0fd6")
		(property "Reference" "R8"
			(at 160.02 104.775 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1M"
			(at 160.02 106.68 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "MyFootprints:Resistor_SMD+THTuniversal_0603to0805_RM7.5_HandSoldering_RevA_Date25Jun2010"
			(at 160.02 104.902 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 160.02 106.68 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 160.02 106.68 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "535979d9-3645-47b8-af48-c20f748b25e7")
		)
		(pin "2"
			(uuid "c0f9884a-d5e4-4d86-a88d-aca59a11acbe")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "R8")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:CP")
		(at 118.11 78.74 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055e0371f")
		(property "Reference" "C2"
			(at 118.745 76.2 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "100u"
			(at 118.745 81.28 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "Capacitors_Elko_ThroughHole:Elko_vert_11.2x6.3mm_RM2.5_CopperClear"
			(at 119.0752 82.55 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 118.11 78.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 118.11 78.74 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "ff4a1ba5-6e20-4f8c-a9fd-4c540a29da82")
		)
		(pin "2"
			(uuid "e60db4f5-00e4-4488-9bf3-408f549b1ab3")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "C2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 118.11 83.82 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055e037b8")
		(property "Reference" "#PWR011"
			(at 118.11 90.17 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 118.11 87.63 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 118.11 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 118.11 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 118.11 83.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "b36ebaad-d9cb-4ac6-bc42-879d9107cf7c")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR011")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "USBi_Programmer-rescue:Conn_01x02-conn")
		(at 218.44 73.66 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055e06a13")
		(property "Reference" "P3"
			(at 218.44 69.85 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "CONN_01X02"
			(at 215.9 73.66 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "fdsp_pinheader:Pin_Header_Straight_1x02"
			(at 218.44 73.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 218.44 73.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 218.44 73.66 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "90f064ba-832d-43bb-ba03-a94f379d8c21")
		)
		(pin "2"
			(uuid "35f13dee-384e-4845-b814-6963ff2044c7")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "P3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 233.68 80.01 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000055e06c48")
		(property "Reference" "#PWR012"
			(at 233.68 86.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 234.95 85.09 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 233.68 80.01 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 233.68 80.01 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 233.68 80.01 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "200b71a5-a958-487a-9448-661a6f8e5483")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR012")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:PWR_FLAG")
		(at 219.71 46.99 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581cf4af")
		(property "Reference" "#FLG0101"
			(at 219.71 44.577 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 219.71 42.418 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 219.71 46.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 219.71 46.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 219.71 46.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "dc8e16a0-c5d4-4d67-b163-82a43564feea")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#FLG0101")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 219.71 49.53 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581cf523")
		(property "Reference" "#PWR0101"
			(at 219.71 55.88 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 220.98 54.61 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 219.71 49.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 219.71 49.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 219.71 49.53 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "60a9b1d1-6ed0-4433-bce4-5d7370b6ff4e")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR0101")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:PWR_FLAG")
		(at 231.14 46.99 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581cf5bf")
		(property "Reference" "#FLG0102"
			(at 231.14 44.577 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 231.14 42.418 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 231.14 46.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 231.14 46.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 231.14 46.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "f294b9d4-86b2-4c25-8d60-1e3e62855faa")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#FLG0102")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:+3.3V")
		(at 232.41 49.53 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581cf801")
		(property "Reference" "#PWR0102"
			(at 228.6 49.53 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 235.966 49.53 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left top)
			)
		)
		(property "Footprint" ""
			(at 232.41 49.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 232.41 49.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 232.41 49.53 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "2b123c24-211a-491c-b154-e0e928894455")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR0102")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "USBi_Programmer-rescue:2N7002-dk_Transistors-FETs-MOSFETs-Single")
		(at 146.05 90.17 270)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005c64fc9a")
		(property "Reference" "Q3"
			(at 151.13 92.71 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "2N7002"
			(at 153.67 95.25 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "digikey-footprints:SOT-23-3"
			(at 151.13 85.09 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Datasheet" "https://www.fairchildsemi.com/datasheets/2N/2N7000.pdf"
			(at 153.67 85.09 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 146.05 90.17 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Digi-Key_PN" "2N7002NCT-ND"
			(at 156.21 85.09 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "MPN" "2N7002"
			(at 158.75 85.09 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Category" "Discrete Semiconductor Products"
			(at 161.29 85.09 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Family" "Transistors - FETs, MOSFETs - Single"
			(at 163.83 85.09 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "DK_Datasheet_Link" "https://www.fairchildsemi.com/datasheets/2N/2N7000.pdf"
			(at 166.37 85.09 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "DK_Detail_Page" "/product-detail/en/on-semiconductor/2N7002/2N7002NCT-ND/244664"
			(at 168.91 85.09 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Description" "MOSFET N-CH 60V 115MA SOT-23"
			(at 171.45 85.09 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Manufacturer" "ON Semiconductor"
			(at 173.99 85.09 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Status" "Active"
			(at 176.53 85.09 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "cd979ce5-062c-4bcf-864b-c52de8037256")
		)
		(pin "3"
			(uuid "8a8e7ead-c207-45db-9b3f-8e14e6957603")
		)
		(pin "2"
			(uuid "fb74e7b7-c4ed-47eb-8cfb-e65f54fc0516")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "Q3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "USBi_Programmer-rescue:2N7002-dk_Transistors-FETs-MOSFETs-Single")
		(at 146.05 123.19 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005c64fe99")
		(property "Reference" "Q4"
			(at 134.62 119.38 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "2N7002"
			(at 133.985 121.92 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "digikey-footprints:SOT-23-3"
			(at 151.13 128.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Datasheet" "https://www.fairchildsemi.com/datasheets/2N/2N7000.pdf"
			(at 153.67 128.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 146.05 123.19 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Digi-Key_PN" "2N7002NCT-ND"
			(at 156.21 128.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "MPN" "2N7002"
			(at 158.75 128.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Category" "Discrete Semiconductor Products"
			(at 161.29 128.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Family" "Transistors - FETs, MOSFETs - Single"
			(at 163.83 128.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "DK_Datasheet_Link" "https://www.fairchildsemi.com/datasheets/2N/2N7000.pdf"
			(at 166.37 128.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "DK_Detail_Page" "/product-detail/en/on-semiconductor/2N7002/2N7002NCT-ND/244664"
			(at 168.91 128.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Description" "MOSFET N-CH 60V 115MA SOT-23"
			(at 171.45 128.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Manufacturer" "ON Semiconductor"
			(at 173.99 128.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Status" "Active"
			(at 176.53 128.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "92e668c8-c89c-4407-b257-2ac8b0c4c73f")
		)
		(pin "3"
			(uuid "b61edca1-4950-4b86-a6db-2866bce4a5d3")
		)
		(pin "2"
			(uuid "f1c25412-29bf-46f8-9b6d-7bb2c13d673d")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "Q4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:+3.3V")
		(at 125.095 102.87 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000068153f4c")
		(property "Reference" "#PWR?"
			(at 128.905 102.87 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 122.555 103.505 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left top)
			)
		)
		(property "Footprint" ""
			(at 125.095 102.87 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 125.095 102.87 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 125.095 102.87 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "b2097745-89c0-484b-88d1-308600678060")
		)
		(instances
			(project ""
				(path "/f506b08e-6af4-4eb1-89c4-06960ac40582"
					(reference "#PWR?")
					(unit 1)
				)
			)
		)
	)
	(sheet_instances
		(path "/"
			(page "1")
		)
	)
	(embedded_fonts no)
)
